# Front-end Foundations Watch Us Build

*We changed the name of this series to "Watch Us Build," so you may see an occasional reference to its former name ("Soup to Bits") in this repository.*

Drew and Jon created a simple portfolio website with HTML, CSS, and a few images in the [Watch Us Build episode](https://www.codeschool.com/screencasts/build-a-portfolio-web-page-with-html-and-css) for the [Front-end Foundations course](https://www.codeschool.com/courses/front-end-foundations) on [Code School](http://codeschool.com).

This repo contains the final source code as shown at the end of the episode.
